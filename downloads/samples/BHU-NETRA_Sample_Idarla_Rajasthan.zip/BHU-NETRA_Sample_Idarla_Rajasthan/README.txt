BHU-NETRA MAP SERVICE - FREE SAMPLE
Village Idarla, Halka Nagani, Tehsil Reodar, District Sirohi, Rajasthan - 1,038 khasra (plots)

Files
  Idarla_Reodar_Sirohi_Khasra.kmz   open in Google Earth (click a plot for its details)
  Idarla_Reodar_Sirohi_Khasra.dxf   open in AutoCAD / any CAD
  Idarla_Reodar_Sirohi_Khasra.shp   open in QGIS / ArcGIS (with .shx .dbf .prj .cpg; .qml = colours for QGIS)
  Idarla_Map_Overlay.jpg            the khasra lines over the ground picture (quality check)

Colours: Yellow = Private / Khatedari land, Green = Govt. land, Orange = Gram Panchayat.
Privacy: owner names of private land are not shown in this sample; Govt. / Panchayat entries are kept.

For planning and reference only - not a legal survey, title document or certified copy.
Private service, not connected with any government department.
Order maps of your villages: https://bhunetramapservice.github.io   Email: bhunetramapservice@gmail.com
