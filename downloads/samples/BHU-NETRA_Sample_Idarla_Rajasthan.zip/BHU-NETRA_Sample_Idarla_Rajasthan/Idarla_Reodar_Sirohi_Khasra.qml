<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="Symbology|Labeling">
 <renderer-v2 type="RuleRenderer" symbollevels="0" enableorderby="0" forceraster="0">
  <rules key="r0">
   <rule key="r1" filter="&quot;KHASRA_NO&quot; = 'WATERMARK'" symbol="0" label="BHU-NETRA MAP SERVICE"/>
   <rule key="r2" filter="&quot;LAND_CAT&quot; LIKE 'Govt%'" symbol="1" label="Govt. Land"/>
   <rule key="r3" filter="&quot;LAND_CAT&quot; = 'Gram Panchayat'" symbol="2" label="Gram Panchayat"/>
   <rule key="r4" filter="ELSE" symbol="3" label="Private / Khatedari"/>
  </rules>
  <symbols>
   <symbol type="fill" name="0" alpha="0.55"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="200,0,0,140" type="QString"/><Option name="outline_color" value="200,0,0,200" type="QString"/><Option name="outline_width" value="0.1" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="1" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="120,200,120,120" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="2" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="255,170,90,140" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="3" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="255,230,150,120" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
  </symbols>
 </renderer-v2>
 <labeling type="simple"><settings calloutType="simple"><text-style fieldName="CASE WHEN &quot;KHASRA_NO&quot; = 'WATERMARK' THEN '' ELSE &quot;KHASRA_NO&quot; END" isExpression="1" fontSize="7" textColor="0,0,0,255"/><placement placement="1"/></settings></labeling>
</qgis>