<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="Symbology|Labeling">
 <renderer-v2 type="RuleRenderer" symbollevels="0" enableorderby="0" forceraster="0">
  <rules key="r0">
   <rule key="r1" filter="&quot;CATEGORY&quot; = 'Boundary'" symbol="0" label="Village boundary"/>
   <rule key="r2" filter="&quot;CATEGORY&quot; = 'Sarkari'" symbol="1" label="Govt. land (Sarkari)"/>
   <rule key="r3" filter="&quot;CATEGORY&quot; = 'Forest'" symbol="2" label="Forest"/>
   <rule key="r4" filter="ELSE" symbol="3" label="Private / Khatedari"/>
  </rules>
  <symbols>
   <symbol type="fill" name="0" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="style" value="no" type="QString"/><Option name="outline_color" value="230,0,0,255" type="QString"/><Option name="outline_width" value="0.8" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="1" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="255,140,26,150" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="2" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="73,201,73,150" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
   <symbol type="fill" name="3" alpha="1"><layer class="SimpleFill"><Option type="Map"><Option name="color" value="255,240,120,120" type="QString"/><Option name="outline_color" value="0,0,0,255" type="QString"/><Option name="outline_width" value="0.2" type="QString"/></Option></layer></symbol>
  </symbols>
 </renderer-v2>
 <labeling type="simple"><settings calloutType="simple"><text-style fieldName="CASE WHEN &quot;CATEGORY&quot; = 'Boundary' THEN '' ELSE &quot;KHASRA_NO&quot; END" isExpression="1" fontSize="7" textColor="0,0,0,255"/><placement placement="1"/></settings></labeling>
</qgis>
