BHU-NETRA MAP SERVICE - FREE SAMPLE
=====================================
Village : Chinnakarpamula, District Nagarkurnool, Telangana
Khasra  : 302 polygons, each with its khasra / survey number
Source  : public land-record map, digitized and georeferenced by BHU-NETRA Map Service

FILES
  01_KML\  - open in Google Earth (double-click) or import in Google Maps / My Maps
  02_DXF\  - open in AutoCAD (or any CAD); WGS 84 / UTM zone 44N, metres; layers KHASRA and KHASRA_NO
  03_SHP\  - open in QGIS / ArcGIS with its attribute table
  Chinnakarpamula_Khasra_List.xlsx - khasra list with areas

WHAT A REAL ORDER ADDS
  - any village / tehsil / district in 19 states, DWG on request
  - colour-coded land category, combined project layer, village outer boundaries
  - field surveys: DGPS, Total Station, topographic, drone, demarcation, route, wind FMB

These maps are for planning / reference use, not a legal survey or title document.

Quotation: https://bhunetramapservice.github.io   |   WhatsApp: chat button on the website   |   bhunetramapservice@gmail.com
