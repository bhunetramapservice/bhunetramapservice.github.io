BHU-NETRA MAP SERVICE - FREE SAMPLE
=====================================
Village : Amaliphala, Tehsil Pratapgarh, District Pratapgarh, Rajasthan
Khasra  : 408 polygons, each with its khasra number
Source  : public land-record map, digitized and georeferenced by BHU-NETRA Map Service

FILES
  01_KML\  - open in Google Earth (double-click) or import in Google Maps / My Maps
  02_DXF\  - open in AutoCAD (or any CAD); real-world UTM zone 43N coordinates, metres; layers for khasra, text, boundary
  03_SHP\  - open in QGIS / ArcGIS; attribute table with khasra no., khata, area (ha / sqm / acre), category
  Amaliphala_Khasra_List.xlsx - khasra list with areas

WHAT A REAL ORDER ADDS
  - any village / tehsil / district in 14 states, DWG on request
  - colour-coded land category (private / non-allotable govt / allotable govt)
  - one combined layer for all project villages, village outer boundaries
  - field surveys: DGPS, Total Station, topographic, drone, demarcation, route

These maps are for planning / reference use, not a legal survey or title document.

Quotation: https://bhunetramapservice.github.io   |   WhatsApp +91 62951 14453   |   bhunetramapservice@gmail.com
